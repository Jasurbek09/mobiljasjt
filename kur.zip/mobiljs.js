 let cart = {
	'Kupit' : 0,
	'Kupit1' : 0,
	'Kupit2' : 0,
	'Kupit3' : 0,
	'Kupit4' : 0,
	'Kupit5' : 0,
	'Kupit6' : 0,
	'Kupit7' : 0,
	'Kupit8' : 0,
	'Kupit9' : 0,
	'Kupit10' : 0,
	'Kupit11' : 0
};

document.onclick = event =>{	
	if (event.target.classList.contains('plus')){
		plusFunction(event.target.dataset.id);
	}
	if (event.target.classList.contains('minus')){
		minusFunction(event.target.dataset.id);
	}
	
};
/*Увеличение количество товара*/
const plusFunction = id =>{
	cart[id]++;
	renderCart();
}

/*Уменьшение количество товара*/
const minusFunction = id =>{
	cart[id]--;
	renderCart();
}
const renderCart = () =>{
	console.log(cart);
}

renderCart();











$(document).ready(function(){

	$('.btn-kupit').click(function(){
		alert("Добавить в корзину?")
	})
})



